from socket import *
import time

serverPort = 12000
serverSocket = socket(AF_INET, SOCK_DGRAM)
serverSocket.bind(('', serverPort))
print ('The server is ready to receive')
#---------------------Local Server Inital Table------------
def initial_LocalServer_Table():
    print ("Initial Local Server Table........")
    list0 = [ 0,'Name         ]', 'Type ', 'Value           ','TTL  ', 'Static']
    list1 = [ 1,'www.csusm.edu ', 'A    ', '144.37.5.45     ',"_____", 1 ]
    list2 = [ 2,'cc.csusm.edu  ', 'A    ', '144.37.5.117    ',"_____", 1 ]
    list3 = [ 3,'cc1.csusm.edu ', 'CNAME', 'cc.csusm.edu    ',"_____", 1 ]
    list4 = [ 4,'cc1.csusm.edu ', 'A    ', '144.37.5.118    ',"_____", 1 ]
    list5 = [ 5,'my.csusm.edu  ', 'A    ', '144.37.5.150    ',"_____", 1 ]
    list6 = [ 6,'qualcomm.com  ', 'NS   ', 'dns.qualcomm.com',"_____", 1 ]
    list7 = [ 7,'viasat.com    ', 'NS   ', 'dns.viasat.com  ',"_____", 1 ]
    print(list0)
    print(list1)
    print(list2)
    print(list3)      
    print(list4)
    print(list5)
    print(list6)
    print(list7)
#----------------End of Inital Table-------------------------
num = 8
while 1:#------while connection is established
#-----------new record will be added to the initial table using this list template-------------
    thislist = ['','Name         ]', 'Type ', 'Value           ','TTL  ', 'Static']
#-----------record number -> incremented at the end of while loop
    thislist[0] = num 
#---------------receiving the request name from client/other server---------------------------
    q1, clientAddress = serverSocket.recvfrom(2048)
    name = q1.decode() #---always decode after receiving data
#------------Querey name stored in record-------------------------------------------------------
    thislist[1] = name
#------------Server responding that they retreived and will return a message back to client-----
    serverSocket.sendto(name.encode(), clientAddress)
#-----------------Local server retreives the response from question #2 and decodes it----------
    q2, clientAddress = serverSocket.recvfrom(2048)
    type = q2.decode()
#-----------------time to store the response in this local RR table----------------------------
    if type == "0":
      thislist[2] = "A"
    if type == "1":
      thislist[2] = "AAAA"
    if type == "2":
      thislist[2] = "CNAME"
    if type == "3":
      thislist[2] = "NS"
#----------- rr table number will increment everytime while loop runs-------
    num+=1
    serverSocket.sendto(type.encode(), clientAddress)

print(thislist)
initial_LocalServer_Table()


